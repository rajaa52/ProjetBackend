-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 02 nov. 2024 à 23:34
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `medicaments_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `medicament`
--

CREATE TABLE `medicament` (
  `id` int(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `dosage` varchar(255) NOT NULL,
  `frequence` varchar(255) NOT NULL,
  `heure_pris` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `medicament`
--

INSERT INTO `medicament` (`id`, `nom`, `dosage`, `frequence`, `heure_pris`) VALUES
(25, 'renomicin', '500mg', '1fois par jour', '05:14:00'),
(31, 'hbdx', 'xxx', 'xxx', '02:11:00'),
(47, 'jhjb', 'jbhkkvhk', 'hbhk', '05:17:00'),
(49, 'fffd', 'ddd', 'dd', '21:28:00'),
(68, 'rajaa1212', '', '', '22:51:00'),
(69, 'rajaa121212', '', '', '22:53:00'),
(104, 'matinMatin', '250mg', '1 fois par jour', '02:43:00'),
(114, 'amoxille', '250mg', '2 fois par jour', '15:42:00'),
(117, 'amoxille', '', '', '15:44:00'),
(119, 'amoxille', '250mg', '2 fois par jour', '23:03:00'),
(120, 'amoxille', '250mg', '2 fois par jour', '23:18:00');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `medicament`
--
ALTER TABLE `medicament`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `medicament`
--
ALTER TABLE `medicament`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
